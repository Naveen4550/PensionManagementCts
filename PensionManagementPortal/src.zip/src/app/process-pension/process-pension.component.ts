import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProcessPensionServices } from '../service/services.component';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-process-pension',
  templateUrl: './process-pension.component.html',
  styleUrls: ['./process-pension.component.css']
})
export class ProcessPensionComponent implements OnInit {
   
   pd = {
    bankServiceCharge:'',
    id:'',
    pensionAmount:''
}
  error='';
isShown: boolean = false ;
  //processPensionInput = {
    aadhaarNumber:string='';
    name:string='';
  //   name: '',
  //  dateOfBirth:'',
  //   pan:'',
  //   salaryEarned:'',
  //   allowances:'',
  //   typeOfPension:'',
  //   bankDetail:null
   
  //};
  
    bankDetail ={
      id :'',
      bankName:'',
      accountNumber:'',
      typeOfBank:''
    }

  submitted = false;
  
  constructor(private processPensionService: ProcessPensionServices,
    private router: Router) { }
  ngOnInit(): void {


  }
    back():void{



      this.aadhaarNumber='';
      this.submitted=false;
      this.isShown=false;
    }

  
  
    
  getAadhaarNumber(): void {
    const data = {
      aadhaarNumber: this.aadhaarNumber,
      name:this.name,
       dateOfBirth:'',
        pan:'',
        salaryEarned:'',
        allowances:'',
       typeOfPension:'',
     bankDetail:this.bankDetail
    };
   
   // this.submitted=true;

    this.processPensionService.create(data)
    .subscribe(
      response => {
        
        console.log(response);
          
        this.pd=response;
       
        console.log('Successs');
       // this.router.navigate(['pensiondetail']);
       this.isShown = ! this.isShown;
        this.submitted = true;
       
        
      },
      error => {

        this.error="Invalid Aadhaar Number";
        console.log('Failure');
        console.log(error);
        this.submitted=false;
        this.isShown=false;
      });
    
     }

  

      


     
    };
  


    
  
   

