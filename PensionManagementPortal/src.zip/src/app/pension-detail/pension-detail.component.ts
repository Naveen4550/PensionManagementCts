import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ProcessPensionComponent } from'../process-pension/process-pension.component'; 
@Component({
  selector: 'app-pension-detail',                      //'app-pension-detail',
  templateUrl: './pension-detail.component.html',
  styleUrls: ['./pension-detail.component.css']
})
export class PensionDetailComponent implements OnInit, AfterViewInit {
  @ViewChild("hello") private hello: ProcessPensionComponent;
   
  
  message: string = '';
  newName: string;
  constructor() { }
  ngOnInit() {
   
  }
  ngAfterViewInit() {

    this.message=this.hello.pd.bankServiceCharge;
  }
  

  

}
